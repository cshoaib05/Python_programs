To install pynotify module use this command :

>> sudo apt-get install python-notify

torrent_mail.py

>> Helps you download a torrent on your pc by just sending an email. Send an email to the email id (which you used while running the program) with subject as 'torrent movie_name' and your torrent will start downloading. You can add any number of torrents by sending multiple mails.

>> qbittorent must be installed on your pc.Visit here to install http://www.qbittorrent.org/download.php

score_sms.py

>> Get regular cricket score updates in the form of an SMS via way2sms (need a way2sms account to run)

tutorialsPointDownloader.py

>> Download all the tutorials from tutorialspoint.com in pdf form

hangman.py + movies.txt

>> Guess the bollywood movie in this hangman game.

anime_down.py

>> To download animes from animeshow.tv automatically.

bing_v1.py

>> Downloads the bing wallpaper every day at midnight and sets it as the wallpaper.

cricinfo_pynotify.py

>> Get Live cricket scores desktop notifications.

cricinfo_terminal.py

>> Get live cricket scores in the terminal.

episode_down_checker.py

>> Download a particular episode of an anime or check for the release of a new episode and download it automatically as soon as it is released

imdb.py

>> Get imdb ratings and summary of any movie in terminal

imdb_compare.py

>> Compare imdb ratings of multiple movies.

imdb_pynotify.py

>>Before using this script install xclip program on your system(needed to clear the clipboard)

>>$ sudo apt-get install xclip

>>Now just run this script and as soon as you copy the name of any movie/tv series it will automatically display the rating and summary of that movie through desktop notification.

manga_down_v2.py

>> Download all the images of a manga from the website manga.animea.net

magnet_link_copier.py

>> Search for torrent files, get the search results from three torrent sites and copy the magnet link of the torrent to the clipboard you wanna download.

news_pynotify.py

>> Get news updates after every 5 minutes through desktop notifications.

pnr_checker.py

>> Check your pnr status .

songs_down.py

>> Download songs .

sort.py

>> Organize your disorganized folder.

xkcd_thread.py

>> Download all the xkcd comics automatically from xkcd.com.

facts.py,quotes.py,vocab.py

>> Displays any random fact,quote or word from a text file after every 5 minutes through desktop notification.

